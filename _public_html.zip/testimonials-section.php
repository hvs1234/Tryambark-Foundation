
  <section class="wide-tb-100 pattern-green pb-0 home-second-testimonials-wrap">
    <div class="container">
      <h1 class="heading-main light-mode green">
        <small>Our Testimonials</small>
        What People Say
      </h1>
      <div class="owl-carousel owl-theme nav-light" id="home-second-testimonials">

        <div class="item">
          <div class="container">
            <div class="row">
              <div class="col-lg-8 col-md-11 mx-auto">
                <div class="client-testimonial-alternate">
                  <div class="client-inner-content">
                    <i class="charity-quotes"></i>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
                  </div>
                  <div class="client-testimonial-icon">
                    <img src="images/team_1.jpg" alt>
                    <div class="text">
                      <div class="name">Person Name</div>
                      <div class="post">Location</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>


        <div class="item">
          <div class="container">
            <div class="row">
              <div class="col-lg-8 col-md-11 mx-auto">
                <div class="client-testimonial-alternate">
                  <div class="client-inner-content">
                    <i class="charity-quotes"></i>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
                  </div>
                  <div class="client-testimonial-icon">
                    <img src="images/team_2.jpg" alt>
                    <div class="text">
                      <div class="name">Person Name</div>
                      <div class="post">Location</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>


        <div class="item">
          <div class="container">
            <div class="row">
              <div class="col-lg-8 col-md-11 mx-auto">
                <div class="client-testimonial-alternate">
                  <div class="client-inner-content">
                    <i class="charity-quotes"></i>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
                  </div>
                  <div class="client-testimonial-icon">
                    <img src="images/team_1.jpg" alt>
                    <div class="text">
                      <div class="name">Person Name</div>
                      <div class="post">Location</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </section>